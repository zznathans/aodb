# aodb chart

Helm chart for [`aodb`](https://github.com/zznathans/aodb)'s API component,
a self-hosted Anarchy Online item/nano database API. Lives at `chart/` in
the [`zznathans/aodb`](https://github.com/zznathans/aodb) monorepo,
alongside the API's own source under `api/` - see the
[repo README](../README.md) for the full picture.

Deploys a FastAPI Deployment + Service. The item dump is downloaded fresh
into memory from a public HTTPS URL (`aodbApi.dumpUrl`) on every pod
start. No Ingress by default - the Service is meant to sit behind
whatever externally-managed ingress/traffic routing your cluster already
uses. Optionally (`aodbApi.ingress.enabled`) the chart deploys its own
Ingress instead, routing `aodbApi.ingress.host` to the Service - set
`aodbApi.ingress.className` for a non-default IngressClass, and
`aodbApi.ingress.tls.enabled` (with `aodbApi.ingress.tls.secretName`) to
terminate TLS there, typically paired with a
`cert-manager.io/cluster-issuer` annotation under
`aodbApi.ingress.annotations` for automatic certificate issuance.

The app stores the loaded dump and its search index in MongoDB
(`aodbApi.mongoUrl`) - by default this chart doesn't deploy Mongo itself,
point it at whatever instance you've already got running. Alternatively,
set `aodbApi.mongo.enabled=true` to have the chart deploy its own
dedicated MongoDB instance instead (a plain single-replica StatefulSet, no
operator required). `aodbApi.mongoUrl` always takes precedence when set,
and one of the two is required - the app has no database to fall back to.

Redis (`aodbApi.redisUrl`) is optional: the app uses it as a cache-aside
layer in front of its more expensive search queries if set, but runs fine
without one - Mongo is the actual source of truth. Set
`aodbApi.redis.enabled=true` to have the chart deploy its own dedicated
Redis instance instead (via the
[redis-operator](https://github.com/OT-CONTAINER-KIT/redis-operator)
`Redis` custom resource, standalone mode - the operator's CRDs must
already be installed in the target cluster). `aodbApi.redisUrl` always
takes precedence when set.

Set `aodbApi.keda.enabled=true` to have the chart deploy a
[KEDA](https://keda.sh) `ScaledObject` autoscaling the Deployment instead of
the static `aodbApi.replicaCount` - requires KEDA to already be installed in
the target cluster. `aodbApi.keda.triggers` takes raw KEDA scaler trigger
definitions (see the [scalers docs](https://keda.sh/docs/latest/scalers/)) -
e.g. cpu, or a prometheus trigger against this app's own `/metrics` endpoint
(`aodbApi.serviceMonitor`).

Client-side analytics (e.g. a Cloudflare Web Analytics beacon or Google
Analytics tag - see the app's own README) aren't in the published image at
all, since the file that carries them is gitignored. Set
`aodbApi.analyticsHtml` to that same raw HTML and the chart renders it into
a ConfigMap and mounts it into the pod for you - no image rebuild needed.

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| aodbApi.analyticsHtml | string | `""` | Raw HTML for client-side analytics (e.g. a Cloudflare beacon or Google Analytics snippet), included verbatim on /api and every browse UI page - see the app's own README for app/templates/_analytics.html. That file is gitignored and never part of the published image, so it can't just be baked in; setting this instead renders it into a ConfigMap and mounts it over that path in the pod. Leave unset (the default) for no client-side analytics at all - this is unrelated to aodbApi.extraEnv's API_ANALYTICS_KEY, which is server-side request analytics, not a page script. |
| aodbApi.dumpUrl | string | `""` | Public HTTPS URL to the item dump zip (a zipped <aodb><item aoid="..." .../></aodb> XML file). Downloaded fresh into memory on whichever pod wins the startup load race, then written to Mongo (see aodbApi.mongoUrl) - no credentials needed for the dump fetch itself. |
| aodbApi.extraEnv | list | `[]` | Extra environment variables to set on the app container, in addition to DUMP_URL, MONGO_URL and REDIS_URL. Each entry is a raw Kubernetes EnvVar (supports valueFrom, e.g. secretKeyRef) - e.g. for API_ANALYTICS_KEY (see the app's own README). |
| aodbApi.extraObjects | list | `[]` | Raw Kubernetes objects to render alongside chart-managed resources. |
| aodbApi.imagePullSecrets | list | `[]` | List of image pull secret names to attach to the ServiceAccount. Leave empty if the registry is public. |
| aodbApi.imageRepository | string | `"ghcr.io/zznathans/aodb"` | Container image registry and repository for the aodb-api image. |
| aodbApi.imageTag | string | `"1.11.3"` | Image tag to deploy. |
| aodbApi.ingress.annotations | object | `{}` | Extra annotations on the Ingress - e.g. cert-manager.io/cluster-issuer, to have cert-manager automatically issue the TLS certificate referenced by ingress.tls.secretName below. |
| aodbApi.ingress.className | string | `""` | IngressClass to use (e.g. "traefik"). Empty uses the cluster's default IngressClass. |
| aodbApi.ingress.enabled | bool | `false` | Create an Ingress routing to this app's Service. Off by default - see the chart README for why (the Service is meant to sit behind whatever externally-managed ingress/traffic routing your cluster already uses; this is an opt-in alternative for clusters that route via a Kubernetes Ingress controller instead). |
| aodbApi.ingress.host | string | `""` | Hostname to route to this app. Required when enabled. |
| aodbApi.ingress.tls.enabled | bool | `false` | Terminate TLS on the Ingress. Typically paired with a cert-manager.io/cluster-issuer annotation above so the certificate is issued automatically. |
| aodbApi.ingress.tls.secretName | string | `""` | Name of the Secret holding the TLS certificate. When using cert-manager, this is the Secret it creates/manages - pick any name. |
| aodbApi.keda.cooldownPeriod | int | `300` | How long (seconds) to wait after the last high metric value before scaling back down. |
| aodbApi.keda.enabled | bool | `false` | Deploy a KEDA ScaledObject to autoscale this app's Deployment. Requires KEDA to already be installed in the target cluster. Safe to enable freely - each replica independently loads its own copy of the dump on startup, no shared state to coordinate across a changing replica count. |
| aodbApi.keda.maxReplicaCount | int | `5` | Maximum replica count KEDA will scale up to. |
| aodbApi.keda.minReplicaCount | int | `1` | Minimum replica count KEDA will scale down to. |
| aodbApi.keda.pollingInterval | int | `30` | How often (seconds) KEDA checks trigger metrics. |
| aodbApi.keda.triggers | list | `[]` | KEDA scaler trigger definitions (see https://keda.sh/docs/latest/scalers/), rendered verbatim into the ScaledObject's spec.triggers. Required (non-empty) when aodbApi.keda.enabled - e.g. a cpu trigger, or a prometheus trigger against this app's own /metrics endpoint (aodbApi.serviceMonitor). |
| aodbApi.mongo.enabled | bool | `false` | Deploy a bundled MongoDB instance (a plain single-replica StatefulSet - no operator assumed, unlike aodbApi.redis below) alongside this app, instead of requiring an externally-provisioned aodbApi.mongoUrl. Off by default: enabling this for an existing installation that already points aodbApi.mongoUrl at its own Mongo would otherwise start deploying an unwanted, unused second Mongo instance. |
| aodbApi.mongo.image.pullPolicy | string | `"IfNotPresent"` | Image pull policy for the bundled MongoDB instance. |
| aodbApi.mongo.image.repository | string | `"mongo"` | Container image repository for the bundled MongoDB instance. |
| aodbApi.mongo.image.tag | string | `"8.0"` | Container image tag for the bundled MongoDB instance. |
| aodbApi.mongo.resources | object | `{"limits":{"cpu":"500m","memory":"768Mi"},"requests":{"cpu":"100m","memory":"256Mi"}}` | Resource requests and limits for the bundled MongoDB instance's container. |
| aodbApi.mongo.storage.size | string | `"1Gi"` | Size of the PersistentVolumeClaim provisioned for the bundled MongoDB instance. The full dump is ~65MB decompressed (see app/dump_loader.py) - this leaves headroom for indexes (name/category/ql/profession/trigram - see app/store.py) and WiredTiger overhead on top of the raw data size. |
| aodbApi.mongoUrl | string | `""` | Connection URL for the MongoDB instance this app uses as its primary datastore (the loaded, indexed item/nano catalog - see the app's own README) - e.g. mongodb://my-mongo:27017/aodb, or mongodb://user:pass@my-mongo:27017/aodb if auth is enabled. Takes precedence over aodbApi.mongo.enabled if both are set. Leave unset (and set aodbApi.mongo.enabled=true) to use the chart's own bundled MongoDB instead of pointing at an externally-provisioned one. Required one way or the other - the app has no database to fall back to. |
| aodbApi.podAnnotations | object | `{}` | Extra annotations to add to the pod template (e.g. for a service mesh sidecar injector or a config-reload trigger). |
| aodbApi.podLabels | object | `{}` | Extra labels to add to the pod template, in addition to the chart-managed `app` label. |
| aodbApi.redis.enabled | bool | `false` | Deploy a bundled Redis instance (via the OT-CONTAINER-KIT/redis-operator `Redis` custom resource, standalone mode only) alongside this app, instead of requiring an externally-provisioned aodbApi.redisUrl. Requires the redis-operator CRDs to already be installed in the target cluster. Off by default: enabling this for an existing installation that already points aodbApi.redisUrl at its own Redis would otherwise start deploying an unwanted, unused second Redis instance. |
| aodbApi.redis.exporter.image.pullPolicy | string | `"Always"` | Image pull policy for the redis-exporter sidecar. |
| aodbApi.redis.exporter.image.repository | string | `"quay.io/opstree/redis-exporter"` | Container image repository for the redis-exporter sidecar. |
| aodbApi.redis.exporter.image.tag | string | `"v1.84.0"` | Container image tag for the redis-exporter sidecar. |
| aodbApi.redis.exporter.resources | object | `{"limits":{"cpu":"100m","memory":"128Mi"},"requests":{"cpu":"100m","memory":"128Mi"}}` | Resource requests and limits for the redis-exporter sidecar container. |
| aodbApi.redis.image.pullPolicy | string | `"IfNotPresent"` | Image pull policy for the bundled Redis instance. |
| aodbApi.redis.image.repository | string | `"quay.io/opstree/redis"` | Container image repository for the bundled Redis instance. |
| aodbApi.redis.image.tag | string | `"v8.6.1"` | Container image tag for the bundled Redis instance. |
| aodbApi.redis.maxmemory | string | `"500mb"` | maxmemory directive for the bundled Redis instance. Needs headroom below aodbApi.redis.resources.limits.memory - too tight a gap caused real OOMKills in production (the memory limit alone isn't enough; Redis needs to know its own budget to evict rather than exceed the container limit). |
| aodbApi.redis.maxmemoryPolicy | string | `"allkeys-lru"` | maxmemory-policy directive for the bundled Redis instance. allkeys-lru is safe here since this instance is dedicated to this app - evicting under memory pressure beats refusing writes. |
| aodbApi.redis.resources | object | `{"limits":{"cpu":"500m","memory":"512Mi"},"requests":{"cpu":"101m","memory":"128Mi"}}` | Resource requests and limits for the bundled Redis instance's main container. Keep the memory limit comfortably above aodbApi.redis.maxmemory above. The CPU limit needs real burst headroom above the steady-state request - a full item/nano dump load builds the name-substring trigram index (app/store.py) via ~3.3M SADD calls, measured at ~32s of Redis-side command time for the SADD calls alone; a limit as tight as the request throttled that burst badly enough to push the whole load past the app's liveness probe window (chart/templates/deployment.yaml), confirmed live in a real crash loop. |
| aodbApi.redis.serviceMonitor.enabled | bool | `false` | Create a Prometheus Operator ServiceMonitor for the bundled Redis instance's exporter metrics. Separate toggle from aodbApi.redis.enabled since it depends on the prometheus-operator CRDs being installed, which isn't guaranteed just because Redis itself is being deployed. |
| aodbApi.redis.serviceMonitor.interval | string | `"30s"` | Scrape interval for the Redis metrics ServiceMonitor. |
| aodbApi.redis.storage.size | string | `"1Gi"` | Size of the PersistentVolumeClaim provisioned for the bundled Redis instance. |
| aodbApi.redisUrl | string | `""` | Connection URL for the Redis instance this app uses as an optional cache-aside layer in front of its more expensive search queries (see the app's own README) - e.g. redis://my-redis:6379/0. Takes precedence over aodbApi.redis.enabled if both are set. Leave both unset to run with no cache at all - Mongo is the source of truth either way, so a missing/unreachable Redis only costs some query latency, never correctness (see app/store.py's _cached_json). |
| aodbApi.replicaCount | int | `1` | Number of pod replicas. Safe to run more than one - each replica independently loads its own in-memory copy of the dump from dumpUrl on startup, no shared state between them. Ignored when aodbApi.keda.enabled - KEDA manages the replica count instead. |
| aodbApi.resources | object | `{"limits":{"cpu":"250m","memory":"512Mi"},"requests":{"cpu":"50m","memory":"128Mi"}}` | Resource requests and limits for the app container. The 256Mi memory limit was too tight for the dump-load step and OOMKilled pods mid-load in a real cluster (confirmed reproducible, not a one-off) - 512Mi gives real headroom above the ~65MB peak RSS the dump parser alone was measured at (app/dump_loader.py), which doesn't account for the rest of the process (interpreter, FastAPI/uvicorn, the Redis client, the raw HTTP response buffer) or growth in the dump/item schema over time. |
| aodbApi.service.port | int | `80` | Port the Service listens on and forwards to the container's 8000. |
| aodbApi.serviceMonitor.enabled | bool | `false` | Create a Prometheus Operator ServiceMonitor scraping this app's own /metrics endpoint (prometheus-fastapi-instrumentator - request counts/latencies/sizes by route). Separate toggle from anything else since it depends on the prometheus-operator CRDs being installed. Same pattern as aodbApi.redis.serviceMonitor for the bundled Redis exporter. |
| aodbApi.serviceMonitor.interval | string | `"30s"` | Scrape interval for this app's ServiceMonitor. |

## Development

```
helm lint chart --strict \
  --set aodbApi.dumpUrl=https://example.invalid/dump.xml.zip \
  --set aodbApi.mongoUrl=mongodb://example-mongo:27017/aodb
helm unittest chart
```

Every `vX.Y.Z` release (shared with the app - see the top-level README's
"Releases" section) gets the chart packaged and published two ways, from
`chart-publish.yml` (triggered by the version-bump commit `release.yml`
pushes to main once a release cuts):

As an OCI artifact at `oci://ghcr.io/zznathans/aodb/charts` - same
registry/namespace as the app image, no `helm repo add` needed, the
recommended path:

```
helm install aodb oci://ghcr.io/zznathans/aodb/charts/aodb --version X.Y.Z
```

And, for third-party tooling that doesn't speak OCI registries yet, to a
classic Helm chart index at https://zznathans.github.io/aodb/charts/:

```
helm repo add aodb https://zznathans.github.io/aodb/charts
helm repo update
helm install aodb aodb/aodb --version X.Y.Z
```
